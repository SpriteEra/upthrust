"use client";

import Image from "next/image";
// import { motion, useMotionValue, useAnimationFrame } from "framer-motion";
// import Image from "next/image";
// import { useRef, useLayoutEffect, useState } from "react";

// const brands = [
//   { name: "Brand 1", src: "/brand1.png" },
//   { name: "Brand 2", src: "/brand2.png" },
//   { name: "Brand 3", src: "/brand3.png" },
//   { name: "Brand 4", src: "/brand4.png" },
//   { name: "Brand 5", src: "/brand5.png" },
// ];

// function InfiniteRow({ direction = -1, speedMultiplier = 60 }) {
//   const x = useMotionValue(0);
//   const speed = speedMultiplier * direction;

//   const containerRef = useRef(null);
//   const isDragging = useRef(false);
//   const lastX = useRef(0);
//   const velocity = useRef(speed);

//   const [itemWidth, setItemWidth] = useState(0);
//   const [totalWidth, setTotalWidth] = useState(0);
//   const [containerWidth, setContainerWidth] = useState(0);

//   // Measure widths
//   useLayoutEffect(() => {
//     const brandItemWidth = 184; // 160px + 24px gap
//     setItemWidth(brandItemWidth);

//     const totalBrandsW = brands.length * brandItemWidth;
//     setTotalWidth(totalBrandsW);

//     // Measure container width
//     if (containerRef.current) {
//       setContainerWidth(containerRef.current.offsetWidth);
//     }

//     // Start in middle for both directions
//     x.set(-totalBrandsW * 10); // 10 sets left
//   }, [x]);

//   // Infinite animation
//   useAnimationFrame((_, delta) => {
//     if (isDragging.current) return;
//     velocity.current += (speed - velocity.current) * 0.02;
//     x.set(x.get() + (velocity.current * delta) / 1000);
//   });

//   // Drag handlers
//   const onPointerDown = (e) => {
//     e.preventDefault();
//     isDragging.current = true;
//     lastX.current = e.clientX;
//     document.body.style.cursor = "grabbing";
//     document.body.style.userSelect = "none";
//   };

//   const onPointerMove = (e) => {
//     if (!isDragging.current) return;
//     const dx = e.clientX - lastX.current;
//     lastX.current = e.clientX;
//     x.set(x.get() + dx);
//     velocity.current = dx * 30;
//   };

//   const onPointerUp = () => {
//     isDragging.current = false;
//     document.body.style.cursor = "";
//     document.body.style.userSelect = "";
//   };

//   // Render infinite brands
//   const renderBrands = () => {
//     if (!totalWidth || !containerWidth) return null;

//     // How many sets needed to cover both directions + buffer
//     const setsNeeded = Math.ceil(containerWidth / totalWidth) + 20;
//     const all = [];
//     for (let i = 0; i < setsNeeded; i++) {
//       all.push(
//         ...brands.map((b, idx) => (
//           <div
//             key={`${i}-${idx}`}
//             className="min-w-[160px] flex items-center justify-center opacity-70 grayscale hover:opacity-100 hover:grayscale-0 transition duration-300"
//             style={{ pointerEvents: "none" }}
//           >
//             <Image
//               src={b.src}
//               alt={b.name}
//               width={120}
//               height={40}
//               draggable={false}
//               className="select-none w-16 xs:w-20 h-full object-contain"
//             />
//           </div>
//         )),
//       );
//     }
//     return all;
//   };

//   return (
//     <div ref={containerRef} className="relative overflow-hidden w-full">
//       {/* <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-[#F7F8F4] to-transparent z-10 pointer-events-none" />
//       <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-[#F7F8F4] to-transparent z-10 pointer-events-none" /> */}

//       <div
//         className="select-none"
//         onPointerDown={onPointerDown}
//         onPointerMove={onPointerMove}
//         onPointerUp={onPointerUp}
//         onPointerLeave={onPointerUp}
//       >
//         <motion.div className="flex gap-8 xs:gap-16 md:gap-24 will-change-transform" style={{ x }}>
//           {renderBrands()}
//         </motion.div>
//       </div>
//     </div>
//   );
// }

// export default function BrandSlider() {
//   return (
//     <section className="py-14 xs:py-20 space-y-14 overflow-hidden">


//       {/* Left to right */}
//       <InfiniteRow direction={1} />
//       {/* Right to left */}
//       <InfiniteRow direction={-1} />
//     </section>
//   );
// }



import { useState, useRef, useEffect } from "react";

function MarqueeRow({ brands, direction = "left", itemWidth = 200 }) {
  const [offset, setOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [velocity, setVelocity] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const dragStartX = useRef(0);
  const dragStartOffset = useRef(0);
  const lastPositions = useRef([]);
  const animationRef = useRef(null);
  const containerRef = useRef(null);

  const totalWidth = itemWidth * brands.length;
  const autoPlaySpeed = direction === "left" ? -1 : 1;

  useEffect(() => {
    if (!containerRef.current) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
        if (!entry.isIntersecting && animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
      },
      { threshold: 0 }
    );

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible || isDragging || Math.abs(velocity) > 0.1) return;

    const animate = () => {
      setOffset((prev) => {
        const newOffset = prev + autoPlaySpeed;
        return ((newOffset % totalWidth) + totalWidth) % totalWidth;
      });
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isDragging, velocity, totalWidth, isVisible, autoPlaySpeed]);

  useEffect(() => {
    if (isDragging || Math.abs(velocity) < 0.1) {
      if (!isDragging) setVelocity(0);
      return;
    }

    const decelerate = () => {
      setVelocity((prev) => {
        const newVelocity = prev * 0.92;
        return Math.abs(newVelocity) < 0.1 ? 0 : newVelocity;
      });

      setOffset((prev) => {
        const newOffset = prev + velocity;
        return ((newOffset % totalWidth) + totalWidth) % totalWidth;
      });

      animationRef.current = requestAnimationFrame(decelerate);
    };

    animationRef.current = requestAnimationFrame(decelerate);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [velocity, isDragging, totalWidth]);

  const calculateVelocity = () => {
    if (lastPositions.current.length < 2) return 0;

    const recentPositions = lastPositions.current.slice(-5);
    const velocities = [];

    for (let i = 1; i < recentPositions.length; i++) {
      const timeDiff = recentPositions[i].time - recentPositions[i - 1].time;
      const posDiff = recentPositions[i].x - recentPositions[i - 1].x;
      if (timeDiff > 0) {
        velocities.push((posDiff / timeDiff) * 16);
      }
    }

    if (velocities.length === 0) return 0;
    return velocities.reduce((a, b) => a + b, 0) / velocities.length;
  };

  const handleStart = (clientX) => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }

    setIsDragging(true);
    setVelocity(0);
    dragStartX.current = clientX;
    dragStartOffset.current = offset;
    lastPositions.current = [{ x: clientX, time: Date.now() }];
  };

  const handleMove = (clientX) => {
    if (!isDragging) return;

    const dragDistance = clientX - dragStartX.current;
    const newOffset = dragStartOffset.current + dragDistance;

    setOffset(((newOffset % totalWidth) + totalWidth) % totalWidth);

    const now = Date.now();
    lastPositions.current.push({ x: clientX, time: now });

    if (lastPositions.current.length > 5) {
      lastPositions.current.shift();
    }
  };

  const handleEnd = () => {
    setIsDragging(false);
    const calculatedVelocity = calculateVelocity();
    setVelocity(calculatedVelocity);
    lastPositions.current = [];
  };

  const handleMouseDown = (e) => {
    e.preventDefault();
    handleStart(e.clientX);
  };

  const handleMouseMove = (e) => {
    e.preventDefault();
    handleMove(e.clientX);
  };

  const handleMouseUp = () => {
    handleEnd();
  };

  const handleTouchStart = (e) => {
    handleStart(e.touches[0].clientX);
  };

  const handleTouchMove = (e) => {
    handleMove(e.touches[0].clientX);
  };

  const handleTouchEnd = () => {
    handleEnd();
  };

  useEffect(() => {
    if (isDragging) {
      const mouseMoveHandler = (e) => handleMouseMove(e);
      const mouseUpHandler = () => handleMouseUp();

      document.addEventListener("mousemove", mouseMoveHandler);
      document.addEventListener("mouseup", mouseUpHandler);

      return () => {
        document.removeEventListener("mousemove", mouseMoveHandler);
        document.removeEventListener("mouseup", mouseUpHandler);
      };
    }
  }, [isDragging, offset]);

  const renderItems = () => {
    const startIndex = Math.floor(-offset / itemWidth) - 2;
    const visibleCount = Math.ceil((typeof window !== "undefined" ? window.innerWidth : 1920) / itemWidth) + 5;

    return Array.from({ length: visibleCount }, (_, i) => {
      const index = (((startIndex + i) % brands.length) + brands.length) % brands.length;
      const brand = brands[index];
      const position = (startIndex + i) * itemWidth + offset;

      return (
        <div
          key={`${brand.id}-${startIndex + i}`}
          className="absolute top-0 h-full flex items-center justify-center"
          style={{
            left: `${position}px`,
            width: `${itemWidth - 20}px`,
            transform: isDragging ? "scale(0.98)" : "scale(1)",
          }}
        >
          <div className="flex items-center justify-center opacity-70 grayscale hover:opacity-100 hover:grayscale-0 transition duration-300"
            style={{ pointerEvents: "none" }}
          >
            <Image
              src={'/brand1.png'}
              alt={brand.name}
              width={120}
              height={40}
              draggable={false}
              className="select-none w-16 xs:w-20 h-full object-contain"
            />
          </div>
        </div>
      );
    });
  };

  return (
    <div
      ref={containerRef}
      className="relative h-32 overflow-hidden cursor-grab active:cursor-grabbing select-none"
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{ touchAction: "pan-y" }}
    >
      {renderItems()}
    </div>
  );
}

function MarqueeColumn({ brands, direction = "up", itemHeight = 200 }) {
  const [offset, setOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [velocity, setVelocity] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const dragStartY = useRef(0);
  const dragStartOffset = useRef(0);
  const lastPositions = useRef([]);
  const animationRef = useRef(null);
  const containerRef = useRef(null);

  const totalHeight = itemHeight * brands.length;
  const autoPlaySpeed = direction === "up" ? -1 : 1;

  useEffect(() => {
    if (!containerRef.current) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
        if (!entry.isIntersecting && animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
      },
      { threshold: 0 }
    );

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible || isDragging || Math.abs(velocity) > 0.1) return;

    const animate = () => {
      setOffset((prev) => {
        const newOffset = prev + autoPlaySpeed;
        return ((newOffset % totalHeight) + totalHeight) % totalHeight;
      });
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isDragging, velocity, totalHeight, isVisible, autoPlaySpeed]);

  useEffect(() => {
    if (isDragging || Math.abs(velocity) < 0.1) {
      if (!isDragging) setVelocity(0);
      return;
    }

    const decelerate = () => {
      setVelocity((prev) => {
        const newVelocity = prev * 0.92;
        return Math.abs(newVelocity) < 0.1 ? 0 : newVelocity;
      });

      setOffset((prev) => {
        const newOffset = prev + velocity;
        return ((newOffset % totalHeight) + totalHeight) % totalHeight;
      });

      animationRef.current = requestAnimationFrame(decelerate);
    };

    animationRef.current = requestAnimationFrame(decelerate);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [velocity, isDragging, totalHeight]);

  const calculateVelocity = () => {
    if (lastPositions.current.length < 2) return 0;

    const recentPositions = lastPositions.current.slice(-5);
    const velocities = [];

    for (let i = 1; i < recentPositions.length; i++) {
      const timeDiff = recentPositions[i].time - recentPositions[i - 1].time;
      const posDiff = recentPositions[i].y - recentPositions[i - 1].y;
      if (timeDiff > 0) {
        velocities.push((posDiff / timeDiff) * 16);
      }
    }

    if (velocities.length === 0) return 0;
    return velocities.reduce((a, b) => a + b, 0) / velocities.length;
  };

  const handleStart = (clientY) => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }

    setIsDragging(true);
    setVelocity(0);
    dragStartY.current = clientY;
    dragStartOffset.current = offset;
    lastPositions.current = [{ y: clientY, time: Date.now() }];
  };

  const handleMove = (clientY) => {
    if (!isDragging) return;

    const dragDistance = clientY - dragStartY.current;
    const newOffset = dragStartOffset.current + dragDistance;

    setOffset(((newOffset % totalHeight) + totalHeight) % totalHeight);

    const now = Date.now();
    lastPositions.current.push({ y: clientY, time: now });

    if (lastPositions.current.length > 5) {
      lastPositions.current.shift();
    }
  };

  const handleEnd = () => {
    setIsDragging(false);
    const calculatedVelocity = calculateVelocity();
    setVelocity(calculatedVelocity);
    lastPositions.current = [];
  };

  const handleMouseDown = (e) => {
    e.preventDefault();
    handleStart(e.clientY);
  };

  const handleMouseMove = (e) => {
    e.preventDefault();
    handleMove(e.clientY);
  };

  const handleMouseUp = () => {
    handleEnd();
  };

  const handleTouchStart = (e) => {
    handleStart(e.touches[0].clientY);
  };

  const handleTouchMove = (e) => {
    handleMove(e.touches[0].clientY);
  };

  const handleTouchEnd = () => {
    handleEnd();
  };

  useEffect(() => {
    if (isDragging) {
      const mouseMoveHandler = (e) => handleMouseMove(e);
      const mouseUpHandler = () => handleMouseUp();

      document.addEventListener("mousemove", mouseMoveHandler);
      document.addEventListener("mouseup", mouseUpHandler);

      return () => {
        document.removeEventListener("mousemove", mouseMoveHandler);
        document.removeEventListener("mouseup", mouseUpHandler);
      };
    }
  }, [isDragging, offset]);

  const renderItems = () => {
    const startIndex = Math.floor(-offset / itemHeight) - 2;
    const visibleCount = Math.ceil((typeof window !== "undefined" ? window.innerHeight : 1080) / itemHeight) + 5;

    return Array.from({ length: visibleCount }, (_, i) => {
      const index = (((startIndex + i) % brands.length) + brands.length) % brands.length;
      const brand = brands[index];
      const position = (startIndex + i) * itemHeight + offset;

      return (
        <div
          key={`${brand.id}-${startIndex + i}`}
          className="absolute left-0 w-full bg-white rounded-2xl flex items-center justify-center shadow-xl transition-transform hover:shadow-2xl"
          style={{
            top: `${position}px`,
            height: `${itemHeight - 20}px`,
            transform: isDragging ? "scale(0.98)" : "scale(1)",
          }}
        >
          <div className="relative w-full h-full p-6 flex flex-col items-center justify-center gap-3">
            <div className="text-6xl">{brand.logo}</div>
            <div className="text-lg font-semibold text-gray-800">{brand.name}</div>
          </div>
        </div>
      );
    });
  };

  return (
    <div
      ref={containerRef}
      className="relative h-full overflow-hidden cursor-grab active:cursor-grabbing select-none"
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{ touchAction: "pan-x" }}
    >
      {renderItems()}
    </div>
  );
}

export default function BrandSlider() {
  const brandsRow1 = [
    { id: 1, name: "Brand 1", logo: "🎨" },
    { id: 2, name: "Brand 2", logo: "🚀" },
    { id: 3, name: "Brand 3", logo: "💎" },
    { id: 4, name: "Brand 4", logo: "⚡" },
    { id: 5, name: "Brand 5", logo: "🎯" },
    { id: 6, name: "Brand 6", logo: "🌟" },
  ];

  const brandsRow2 = [
    { id: 7, name: "Brand 7", logo: "🎭" },
    { id: 8, name: "Brand 8", logo: "🎪" },
    { id: 9, name: "Brand 9", logo: "🎬" },
    { id: 10, name: "Brand 10", logo: "🎮" },
    { id: 11, name: "Brand 11", logo: "🎲" },
    { id: 12, name: "Brand 12", logo: "🎸" },
  ];

  const brandsCol1 = [
    { id: 13, name: "Brand 13", logo: "🎹" },
    { id: 14, name: "Brand 14", logo: "🎺" },
    { id: 15, name: "Brand 15", logo: "🎻" },
    { id: 16, name: "Brand 16", logo: "🥁" },
  ];

  const brandsCol2 = [
    { id: 17, name: "Brand 17", logo: "🎤" },
    { id: 18, name: "Brand 18", logo: "🎧" },
    { id: 19, name: "Brand 19", logo: "📻" },
    { id: 20, name: "Brand 20", logo: "🎼" },
  ];

  return (
    <div className="py-14 xs:py-20 space-y-14 overflow-hidden">

      <div className="flex-1 flex flex-col justify-center gap-0">
        <MarqueeRow brands={brandsRow1} direction="left" />
        <MarqueeRow brands={brandsRow2} direction="right" />
      </div>
    </div>
  );
}