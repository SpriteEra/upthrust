"use client"
import { Play } from 'lucide-react'
import React from 'react'

import { useEffect, useRef } from "react"
import Image from "next/image"
import gsap from "gsap"

gsap.registerPlugin()

const brands = [
    { name: "Brand 3", src: "/banner3.png" },
    { name: "Brand 4", src: "/banner4.png" },
    { name: "Brand 6", src: "/banner6.png" },
    { name: "Brand 1", src: "/banner1.png" },
    { name: "Brand 2", src: "/banner2.png" },
    { name: "Brand 5", src: "/banner5.png" },
]
const brands2 = [
    { name: "Brand 2", src: "/banner2.png" },
    { name: "Brand 1", src: "/banner1.png" },
    { name: "Brand 3", src: "/banner3.png" },
    { name: "Brand 5", src: "/banner5.png" },
    { name: "Brand 4", src: "/banner4.png" },
    { name: "Brand 6", src: "/banner6.png" },
]
const brands3 = [
    { name: "Brand 2", src: "/banner2.png" },
    { name: "Brand 3", src: "/banner3.png" },
    { name: "Brand 4", src: "/banner4.png" },
    { name: "Brand 5", src: "/banner5.png" },
    { name: "Brand 1", src: "/banner1.png" },
    { name: "Brand 6", src: "/banner6.png" },
]

function useSupersideSlider(direction = -1) {
    const trackRef = useRef(null)

    useEffect(() => {
        const el = trackRef.current
        if (!el) return

        const totalHeight = el.scrollHeight / 2
        let baseSpeed = 0.35 * direction

        const tick = () => {
            let y = gsap.getProperty(el, "y")
            y += baseSpeed

            if (y <= -totalHeight) y += totalHeight
            if (y >= 0) y -= totalHeight

            gsap.set(el, { y })
        }

        gsap.ticker.add(tick)

        return () => {
            gsap.ticker.remove(tick)
        }
    }, [direction])

    return trackRef
}
function Column({ direction, data }) {
    const ref = useSupersideSlider(direction)

    return (
        <div className="overflow-hidden h-full select-none">
            <div
                ref={ref}
                className="flex flex-col gap-2 md:gap-4 3xl:gap-10"
                style={{
                    userSelect: "none",
                    WebkitUserDrag: "none",
                }}
            >
                {[...data, ...data].map((b, i) => (
                    <div
                        key={i}
                        className="h-25 md:h-[320px] flex items-center justify-center rounded-md md:rounded-lg"
                        style={{ pointerEvents: "none" }}
                    >
                        <Image
                            src={b.src}
                            alt={b.name}
                            width={200}
                            height={300}
                            className="h-full w-full object-cover rounded-lg"
                        />
                    </div>
                ))}
            </div>
        </div>
    )
}

// export function HeroVerticleSlider() {
//     return (
//         <div className="grid grid-cols-3 gap-6 3xl:gap-10">
//             {/* left column → up */}
//             <Column direction={-1} data={brands} />

//             {/* right column → down */}
//             <Column direction={1} data={brands2} />
//             <Column direction={-1} data={brands3} />
//         </div>
//     )
// }

const UGCAdsPlaybook = () => {
    return (
        <div className='px-2 xs:px-10 mb-20'>

            <div className=' bg-[#4E8679] text-white grid grid-cols-7 rounded-md xs:rounded-xl max-h-60 xs:max-h-80 md:max-h-120 lg:max-h-[110vh] overflow-hidden'>
                <div className='col-span-1'>
                    <Column direction={-1} data={brands} />
                </div>
                <div className='col-span-5 p-1 xs:p-6 flex flex-col justify-evenly gap-2 xs:gap-2 max-h-60 xs:max-h-80 md:max-h-120 lg:max-h-[110vh]'>
                    <div className='font-medium text-[28px] md:text-8xl xl:text-[100px] italic 3xl:text-[140px] leading-tight capitalize'>
                        <p>A Step-by-step</p>
                        <p>Guide to</p>
                    </div>
                    <div className='flex items-center justify-center'>
                        <div className='bg-white/40 rounded-md xs:rounded-[10px] px-5 xs:px-12 py-2.5 xs:py-6'>
                            <Play className='size-6 xs:size-11 3xl:size-12' fill='#ffffff' />
                        </div>
                    </div>
                    <div className='font-medium text-[32px] md:text-[100px] xl:text-[120px] italic 3xl:text-[160px] font-instrument self-end w-full max-w-[82%] xs:max-w-[70%] leading-tight'>
                        <p>Scale</p>
                        <p>Your Brand</p>
                    </div>
                </div>
                <div>
                    <Column direction={1} data={brands} />
                </div>
            </div>
        </div>
    )
}

export default UGCAdsPlaybook